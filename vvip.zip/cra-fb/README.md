
<p align="center"> 
 PENGUNJUNG 

 <img src="https://profile-counter.glitch.me/FIRandZAH/count.svg" alt="Visitors">
</p>

<p align="center">
  Script by: FIRZAH
</p>

[![Typing SVG](https://readme-typing-svg.demolab.com?font=Fira+Code&pause=1000&color=00FF00&background=31FF9400&width=435&lines=Script+cracking+Facebook)](https://git.io/typing-svg)

## 🚀 Install and Run

Untuk menginstal dan menjalankan script crack ini, ikuti langkah-langkah berikut:

```sh
pkg update && pkg upgrade -y
pkg install python -y
pkg install python-pip -y
pkg install git -y
pip install rich
pip install requests
pip install pycryptodome
termux-setup-storage (izinkan)
git clone https://github.com/FIRandZAH/crack
cd crack
git pull
python main.py
```

<br>
<p align="center">
  <img src="foto/foto.jpg" alt="Screenshot" width="400"/>
</p>


- **fitur script**
- **1** crack gmail.
- **2** crack file.
- **3** dump masal.
- **4** dump file.
- **5** sandi tambahin.
- **6** pilih list password nama lengkap,nama depan+123,1234,12345.
- **7** pilih user agent.
## 📬 Contact

Jika kamu memiliki pertanyaan atau masukan, jangan ragu untuk menghubungi saya di WhatsApp melalui tautan ini: https://wa.me/+6283170597744.
